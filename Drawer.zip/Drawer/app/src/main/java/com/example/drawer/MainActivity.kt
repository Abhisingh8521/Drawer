package com.example.drawer

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import bottomnavigation_fragment.AcountFragment
import bottomnavigation_fragment.LibraryFragment
import bottomnavigation_fragment.LogoutFragment
import bottomnavigation_fragment.MusicFragment
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import drawer_fragment.HomeFragment
import drawer_fragment.PrivicyFragment
import drawer_fragment.SettingFragment

class MainActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        val navigationView = findViewById<NavigationView>(R.id.navigationView)

        toolbar.setNavigationOnClickListener {
            drawerLayout.open()
        }
        navigationView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.itemHome -> loadfragment(HomeFragment())
                R.id.itemSetting -> loadfragment(SettingFragment())
                R.id.itemSetting -> loadfragment(SettingFragment())
                R.id.itemPrevicy -> loadfragment(PrivicyFragment())

            }
            true
        }
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.background = null
        loadfragment(AcountFragment())
        bottomNavigationView.setOnNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.nav_account -> loadfragment(AcountFragment())
                R.id.nav_library -> loadfragment(LibraryFragment())
                R.id.nav_music -> loadfragment(MusicFragment())
                R.id.nav_logout -> loadfragment(LogoutFragment())
            }
            true

        }


    }


    private fun loadfragment(fragment: Fragment) {
        val drawerLayout = findViewById<DrawerLayout>(R.id.drawer_layout)
        supportFragmentManager.beginTransaction().replace(R.id.frame, fragment).commit()
        drawerLayout.close()

    }


}











